package com.example.lighthouse_weather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
