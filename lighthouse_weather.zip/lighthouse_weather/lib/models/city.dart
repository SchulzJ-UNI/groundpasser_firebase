import 'package:flutter/material.dart';

class City {
  final int id;
  String name;
  IconData icon;

  City(this.id, {this.name, this.icon});
}